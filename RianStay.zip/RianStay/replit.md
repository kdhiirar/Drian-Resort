# Overview

D'Rian Resort is a traditional Malaysian heritage resort website featuring a React frontend with Express.js backend. The application showcases the resort's accommodation options, facilities, and services with a focus on Malaysian cultural themes and eco-friendly luxury hospitality. The site includes multiple pages for rooms, facilities, about us, contact, and location information with a sophisticated UI built using shadcn/ui components and Tailwind CSS.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **Routing**: Wouter for client-side routing with pages for home, facilities, rooms, about, contact, location, and 404
- **UI Framework**: shadcn/ui components with Radix UI primitives for accessible, customizable components
- **Styling**: Tailwind CSS with custom Malaysian-themed color variables and design tokens
- **State Management**: TanStack React Query for server state management and data fetching
- **Form Handling**: React Hook Form with Zod validation schemas

## Backend Architecture
- **Framework**: Express.js with TypeScript running on Node.js
- **Build System**: ESBuild for production bundling with development using tsx
- **Development Setup**: Vite integration for HMR and middleware mode during development
- **API Structure**: RESTful API design with `/api` prefix for all backend routes
- **Storage Interface**: Abstracted storage layer with IStorage interface, currently implemented as MemStorage (in-memory) but designed for easy database integration

## Database Layer
- **ORM**: Drizzle ORM configured for PostgreSQL with Neon Database serverless connection
- **Schema Management**: Centralized schema definitions in `shared/schema.ts` with Zod integration
- **Migrations**: Drizzle Kit for database migrations stored in `./migrations` directory
- **Type Safety**: Full TypeScript integration with inferred types from Drizzle schema

## Design System
- **Typography**: Custom font stack with Playfair Display (serif), Open Sans (sans-serif), and system monospace
- **Color Palette**: Malaysian-inspired theme with terracotta, green, gold, cream, and burgundy colors
- **Component Library**: Comprehensive shadcn/ui component set including forms, navigation, cards, dialogs, and data display components
- **Responsive Design**: Mobile-first approach with Tailwind CSS breakpoints and mobile navigation sheet

## Development Workflow
- **Package Management**: npm with lockfile for consistent dependencies
- **TypeScript Configuration**: Strict mode with path mapping for clean imports (@/, @shared/, @assets/)
- **Build Process**: Separate client and server builds with Vite for frontend and ESBuild for backend
- **Development Server**: Integrated Vite dev server with Express middleware for seamless development experience

# External Dependencies

## Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, React Hook Form, TanStack React Query
- **Backend Runtime**: Express.js, Node.js with tsx for TypeScript execution
- **Build Tools**: Vite, ESBuild, TypeScript compiler

## Database & ORM
- **Database**: Neon Database (PostgreSQL serverless)
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Validation**: Zod for runtime type validation and schema generation

## UI & Styling
- **Component Library**: Radix UI primitives (@radix-ui/* packages)
- **Styling**: Tailwind CSS with PostCSS and Autoprefixer
- **Icons**: Lucide React for consistent iconography
- **Fonts**: Google Fonts integration (Playfair Display, Open Sans)

## Development & Build Tools
- **Development**: Replit-specific plugins for runtime error overlay and cartographer
- **Session Management**: connect-pg-simple for PostgreSQL session store
- **Utilities**: date-fns for date manipulation, clsx and class-variance-authority for styling utilities
- **Carousel**: Embla Carousel React for image galleries and content sliders

## Hosting & Deployment
- **Platform**: Configured for Replit deployment with environment-specific configurations
- **Environment Variables**: DATABASE_URL for database connection
- **Static Assets**: Served through Vite in development and Express static middleware in production
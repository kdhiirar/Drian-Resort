import { Link } from "wouter";
import { Leaf } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-malaysian-green text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <Leaf className="text-malaysian-gold text-2xl mr-2" />
              <h3 className="text-xl font-serif font-bold">D'Rian Resort</h3>
            </div>
            <p className="text-gray-300 mb-4">Experience authentic Malaysian hospitality in our eco-friendly traditional resort.</p>
            <div className="flex space-x-3">
              <a href="#" className="text-gray-300 hover:text-malaysian-gold transition-colors" data-testid="footer-facebook">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-malaysian-gold transition-colors" data-testid="footer-instagram">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-malaysian-gold transition-colors" data-testid="footer-twitter">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-malaysian-gold transition-colors" data-testid="footer-youtube">
                <i className="fab fa-youtube"></i>
              </a>
            </div>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><Link href="/" className="text-gray-300 hover:text-malaysian-gold transition-colors" data-testid="footer-home">Home</Link></li>
              <li><Link href="/rooms" className="text-gray-300 hover:text-malaysian-gold transition-colors" data-testid="footer-rooms">Rooms</Link></li>
              <li><Link href="/facilities" className="text-gray-300 hover:text-malaysian-gold transition-colors" data-testid="footer-facilities">Facilities</Link></li>
              <li><Link href="/energy" className="text-gray-300 hover:text-malaysian-gold transition-colors" data-testid="footer-energy">Energy</Link></li>
              <li><Link href="/about" className="text-gray-300 hover:text-malaysian-gold transition-colors" data-testid="footer-about">About Us</Link></li>
              <li><Link href="/contact" className="text-gray-300 hover:text-malaysian-gold transition-colors" data-testid="footer-contact">Contact</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4">Services</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-malaysian-gold transition-colors" data-testid="footer-room-service">Room Service</a></li>
              <li><a href="#" className="text-gray-300 hover:text-malaysian-gold transition-colors" data-testid="footer-spa">Traditional Spa</a></li>
              <li><a href="#" className="text-gray-300 hover:text-malaysian-gold transition-colors" data-testid="footer-transfer">Airport Transfer</a></li>
              <li><a href="#" className="text-gray-300 hover:text-malaysian-gold transition-colors" data-testid="footer-tours">Tour Booking</a></li>
              <li><a href="#" className="text-gray-300 hover:text-malaysian-gold transition-colors" data-testid="footer-car-rental">Car Rental</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Info</h4>
            <div className="space-y-2 text-gray-300">
              <p><i className="fas fa-map-marker-alt mr-2"></i>Malacca, Malaysia</p>
              <p><i className="fas fa-phone mr-2"></i>+60 6-123 4567</p>
              <p><i className="fas fa-envelope mr-2"></i>info@drianresort.com</p>
            </div>
          </div>
        </div>
        <div className="border-t border-gray-600 mt-8 pt-8 text-center">
          <p className="text-gray-300">&copy; 2024 D'Rian Resort. All rights reserved. | Traditional Malaysian Hospitality | Eco-Friendly Luxury</p>
        </div>
      </div>
    </footer>
  );
}

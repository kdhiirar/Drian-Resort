import { Card, CardContent } from "@/components/ui/card";

const offers = [
  {
    title: "Hari Raya Aidilfitri",
    discount: "25% OFF",
    description: "Celebrate the festival of lights with our most generous discount",
    icon: "fas fa-mosque",
    gradient: "from-malaysian-terracotta to-malaysian-burgundy",
  },
  {
    title: "Deepavali",
    discount: "20% OFF",
    description: "Festival of lights celebration package",
    icon: "fas fa-om",
    gradient: "from-yellow-500 to-orange-500",
  },
  {
    title: "Chinese New Year",
    discount: "20% OFF",
    description: "Welcome prosperity with our special rates",
    icon: "fas fa-dragon",
    gradient: "from-red-600 to-yellow-500",
  },
  {
    title: "Christmas",
    discount: "20% OFF",
    description: "Holiday season celebration discount",
    icon: "fas fa-gifts",
    gradient: "from-green-600 to-red-600",
  },
];

export default function SpecialOffers() {
  return (
    <section className="py-20 bg-malaysian-cream">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-serif font-bold text-malaysian-green mb-4">Special Holiday Offers</h2>
          <p className="text-lg text-warm-gray max-w-2xl mx-auto">Celebrate Malaysia's diverse heritage with exclusive savings during festive seasons</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {offers.map((offer, index) => (
            <Card key={index} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300" data-testid={`offer-${offer.title.toLowerCase().replace(/\s+/g, '-')}`}>
              <div className={`bg-gradient-to-r ${offer.gradient} p-6 text-white text-center`}>
                <i className={`${offer.icon} text-3xl mb-4`}></i>
                <h3 className="text-xl font-semibold">{offer.title}</h3>
              </div>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-malaysian-terracotta mb-2">{offer.discount}</div>
                <p className="text-warm-gray">{offer.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

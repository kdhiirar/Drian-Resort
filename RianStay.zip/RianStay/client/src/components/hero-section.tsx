import { Button } from "@/components/ui/button";
import { ChevronDown, Leaf } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="min-h-screen relative overflow-hidden" data-testid="hero-section">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat" 
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')"
        }}
      ></div>
      <div className="absolute inset-0 bg-black/40"></div>
      <div className="relative z-10 flex items-center justify-center min-h-screen text-center text-white px-4">
        <div className="max-w-4xl mx-auto">
          <div className="mb-6">
            <Leaf className="text-malaysian-gold text-4xl mb-4 mx-auto" />
          </div>
          <h1 className="text-5xl md:text-7xl font-serif font-bold mb-6 leading-tight">Welcome to D'Rian Resort</h1>
          <p className="text-xl md:text-2xl mb-8 leading-relaxed">Experience Traditional Malaysian Hospitality in Modern Comfort</p>
          <p className="text-lg mb-10 max-w-2xl mx-auto leading-relaxed">Discover the perfect blend of heritage and luxury in our eco-friendly resort, nestled in the heart of historical Malacca near pristine beaches.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              className="bg-malaysian-terracotta text-white px-8 py-4 rounded-full hover:bg-malaysian-burgundy transition-all duration-300 transform hover:scale-105 font-semibold text-lg"
              data-testid="explore-rooms-button"
            >
              Explore Rooms
            </Button>
            <Button 
              variant="outline"
              className="border-2 border-white text-white px-8 py-4 rounded-full hover:bg-white hover:text-malaysian-green transition-all duration-300 font-semibold text-lg"
              data-testid="special-offers-button"
            >
              Special Offers
            </Button>
          </div>
        </div>
      </div>
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <ChevronDown className="text-white text-2xl" />
      </div>
    </section>
  );
}

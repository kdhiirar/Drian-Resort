import HeroSection from "@/components/hero-section";
import SpecialOffers from "@/components/special-offers";

export default function Home() {
  return (
    <div className="pt-0">
      <HeroSection />
      <SpecialOffers />
    </div>
  );
}

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin, Umbrella, Plane, ShoppingBag, Navigation } from "lucide-react";

export default function Location() {
  const locationFeatures = [
    {
      icon: MapPin,
      text: "Historical Malacca City Center - 15 minutes",
    },
    {
      icon: Umbrella,
      text: "Malacca Beaches - 10 minutes",
    },
    {
      icon: Plane,
      text: "Malacca Airport - 25 minutes",
    },
    {
      icon: ShoppingBag,
      text: "Jonker Street Night Market - 20 minutes",
    },
  ];

  return (
    <div className="pt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-serif font-bold text-malaysian-green mb-4">Our Location</h1>
          <p className="text-lg text-warm-gray max-w-2xl mx-auto">Discover D'Rian Resort in the heart of historic Malacca, Malaysia's UNESCO World Heritage city</p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12">
          <div>
            <h2 className="text-2xl font-serif font-semibold text-malaysian-green mb-6">Experience Historic Malacca</h2>
            <p className="text-warm-gray mb-6 leading-relaxed">Located in the culturally rich state of Malacca, our resort offers easy access to historical sites, traditional markets, and pristine beaches. The strategic location allows guests to explore the UNESCO World Heritage sites while enjoying the tranquility of our traditional Malaysian sanctuary.</p>
            
            <div className="space-y-4 mb-8">
              {locationFeatures.map((feature, index) => (
                <div key={index} className="flex items-center" data-testid={`location-feature-${index}`}>
                  <feature.icon className="text-malaysian-terracotta mr-3 h-5 w-5" />
                  <span className="text-warm-gray">{feature.text}</span>
                </div>
              ))}
            </div>
            
            <Button className="bg-malaysian-terracotta text-white hover:bg-malaysian-burgundy transition-colors duration-200 font-semibold" data-testid="get-directions-button">
              <Navigation className="mr-2 h-4 w-4" />
              Get Directions
            </Button>
          </div>
          
          <Card className="bg-white rounded-xl shadow-lg overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1539650116574-75c0c6d73f6e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400" 
              alt="Scenic Malacca coastline with traditional architecture" 
              className="w-full h-64 object-cover"
              data-testid="malacca-coastline-image"
            />
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold text-malaysian-green mb-3">GPS Coordinates</h3>
              <p className="text-warm-gray mb-4" data-testid="gps-coordinates">2.2065° N, 102.2464° E</p>
              <div className="bg-gray-100 p-4 rounded-lg">
                <p className="text-sm text-warm-gray font-mono" data-testid="full-address">D'Rian Resort, Jalan Pantai Klebang, 75200 Malacca, Malaysia</p>
              </div>
              <div className="mt-4 h-32 bg-gray-200 rounded-lg flex items-center justify-center" data-testid="interactive-map-placeholder">
                <p className="text-gray-500">Interactive Map Loading...</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

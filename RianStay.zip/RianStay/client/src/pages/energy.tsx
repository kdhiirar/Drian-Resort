import { Card, CardContent } from "@/components/ui/card";
import { Battery, Zap, Leaf, Sun, Droplets, Recycle } from "lucide-react";

const energyFeatures = [
  {
    icon: Sun,
    title: "100% Solar Powered",
    description: "Our resort operates entirely on clean solar energy with advanced photovoltaic panels covering our rooftops",
    color: "text-yellow-500",
    bgColor: "bg-yellow-50",
  },
  {
    icon: Battery,
    title: "Energy Storage System",
    description: "High-capacity battery systems ensure uninterrupted power supply even during cloudy days",
    color: "text-green-600",
    bgColor: "bg-green-50",
  },
  {
    icon: Zap,
    title: "Smart Grid Technology",
    description: "Intelligent energy management system optimizes power distribution across all resort facilities",
    color: "text-blue-600",
    bgColor: "bg-blue-50",
  },
  {
    icon: Droplets,
    title: "Water Conservation",
    description: "Solar-powered water heating and recycling systems reduce environmental impact",
    color: "text-cyan-600",
    bgColor: "bg-cyan-50",
  },
  {
    icon: Leaf,
    title: "Carbon Neutral Resort",
    description: "Zero carbon footprint operations with renewable energy and sustainable practices",
    color: "text-malaysian-green",
    bgColor: "bg-green-50",
  },
  {
    icon: Recycle,
    title: "Waste Management",
    description: "Solar-powered waste processing and composting systems for organic waste recycling",
    color: "text-malaysian-terracotta",
    bgColor: "bg-orange-50",
  },
];

const energyStats = [
  { value: "350kW", label: "Solar Panel Capacity" },
  { value: "100%", label: "Renewable Energy" },
  { value: "500MWh", label: "Annual Energy Production" },
  { value: "0%", label: "Carbon Emissions" },
];

const sustainabilityInitiatives = [
  {
    title: "Traditional Architecture + Modern Efficiency",
    description: "Our heritage building design incorporates modern insulation and energy-efficient systems while preserving Malaysian architectural authenticity.",
    image: "https://images.unsplash.com/photo-1509391366360-2e959784a276?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    alt: "Traditional Malaysian building with solar panels",
  },
  {
    title: "Green House Design",
    description: "Passive cooling systems, natural ventilation, and green roofing reduce energy consumption while maintaining guest comfort.",
    image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    alt: "Eco-friendly green building with sustainable features",
  },
  {
    title: "Solar Installation Excellence",
    description: "State-of-the-art photovoltaic systems seamlessly integrated into our traditional rooflines without compromising aesthetic appeal.",
    image: "https://images.unsplash.com/photo-1624397640148-949b1732bb0a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    alt: "Modern solar panel installation on resort buildings",
  },
];

export default function Energy() {
  return (
    <div className="pt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-serif font-bold text-malaysian-green mb-4">Sustainable Energy Solutions</h1>
          <p className="text-lg text-warm-gray max-w-2xl mx-auto">Experience luxury hospitality powered by 100% renewable energy, showcasing Malaysia's commitment to environmental sustainability</p>
        </div>
        
        {/* Energy Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {energyStats.map((stat, index) => (
            <Card key={index} className="bg-malaysian-cream text-center p-6" data-testid={`energy-stat-${stat.label.toLowerCase().replace(/\s+/g, '-')}`}>
              <CardContent className="p-0">
                <div className="text-3xl font-bold text-malaysian-terracotta mb-2">{stat.value}</div>
                <div className="text-warm-gray font-medium">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Energy Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {energyFeatures.map((feature, index) => (
            <Card key={index} className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-300" data-testid={`energy-feature-${feature.title.toLowerCase().replace(/\s+/g, '-')}`}>
              <CardContent className="p-0">
                <div className={`w-16 h-16 ${feature.bgColor} rounded-full flex items-center justify-center mb-4`}>
                  <feature.icon className={`${feature.color} h-8 w-8`} />
                </div>
                <h3 className="text-xl font-semibold text-malaysian-green mb-3">{feature.title}</h3>
                <p className="text-warm-gray">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Sustainability Initiatives */}
        <div className="mb-16">
          <h2 className="text-3xl font-serif font-semibold text-malaysian-green mb-8 text-center">Our Green Initiatives</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {sustainabilityInitiatives.map((initiative, index) => (
              <Card key={index} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300" data-testid={`initiative-${initiative.title.toLowerCase().replace(/\s+/g, '-')}`}>
                <img src={initiative.image} alt={initiative.alt} className="w-full h-48 object-cover" />
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold text-malaysian-green mb-3">{initiative.title}</h3>
                  <p className="text-warm-gray">{initiative.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Environmental Impact */}
        <Card className="bg-gradient-to-r from-malaysian-green to-malaysian-terracotta text-white rounded-xl p-8">
          <div className="text-center">
            <h2 className="text-3xl font-serif font-bold mb-4">Environmental Impact</h2>
            <p className="text-lg mb-6 max-w-3xl mx-auto">By choosing D'Rian Resort, you're supporting sustainable tourism and helping preserve Malaysia's natural beauty for future generations. Our solar energy systems prevent over 200 tons of CO2 emissions annually.</p>
            <div className="grid md:grid-cols-3 gap-6 mt-8">
              <div className="text-center" data-testid="impact-co2-prevented">
                <div className="text-3xl font-bold mb-2">200+</div>
                <div className="text-sm">Tons CO2 Prevented Annually</div>
              </div>
              <div className="text-center" data-testid="impact-trees-equivalent">
                <div className="text-3xl font-bold mb-2">2,500+</div>
                <div className="text-sm">Trees Equivalent Impact</div>
              </div>
              <div className="text-center" data-testid="impact-clean-energy">
                <div className="text-3xl font-bold mb-2">100%</div>
                <div className="text-sm">Clean Energy Operations</div>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
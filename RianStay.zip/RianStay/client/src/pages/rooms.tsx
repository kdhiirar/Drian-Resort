import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Bed, Wifi, Tv, Coffee, Eye, Armchair, Bath, Utensils, Umbrella, Crown, Crown as HotTub, Bell, Car } from "lucide-react";

const rooms = [
  {
    title: "Standard Room",
    description: "Comfortable accommodation featuring traditional Malaysian design elements with modern conveniences.",
    image: "https://images.unsplash.com/photo-1631049307264-da0ec9d70304?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    alt: "Standard Room with traditional Malaysian decor",
    features: [
      { icon: Bed, text: "Queen-size bed" },
      { icon: Wifi, text: "Complimentary WiFi" },
      { icon: Tv, text: "Smart TV" },
      { icon: Coffee, text: "Coffee/Tea facilities" },
    ],
  },
  {
    title: "Deluxe Room",
    description: "Enhanced space and luxury with premium Malaysian craftsmanship and garden views.",
    image: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    alt: "Deluxe Room with premium Malaysian furnishings",
    features: [
      { icon: Bed, text: "King-size bed" },
      { icon: Eye, text: "Garden view" },
      { icon: Armchair, text: "Seating area" },
      { icon: Bath, text: "Premium bathroom" },
    ],
  },
  {
    title: "Premier Room",
    description: "Sophisticated accommodation with authentic Malaysian heritage elements and premium amenities.",
    image: "https://images.unsplash.com/photo-1611892440504-42a792e24d32?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    alt: "Premier Room with traditional Malaysian luxury design",
    features: [
      { icon: Bed, text: "King-size bed + sofa bed" },
      { icon: Eye, text: "Pool view" },
      { icon: Utensils, text: "Mini kitchenette" },
      { icon: Umbrella, text: "Private balcony" },
    ],
  },
  {
    title: "Executive Suite",
    description: "Ultimate luxury with traditional Malaysian royal design influences and exclusive services.",
    image: "https://images.unsplash.com/photo-1590490360182-c33d57733427?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    alt: "Luxury Suite with traditional Malaysian royal design",
    features: [
      { icon: Crown, text: "Separate living area" },
      { icon: HotTub, text: "Private jacuzzi" },
      { icon: Bell, text: "Butler service" },
      { icon: Car, text: "Airport transfer" },
    ],
  },
];

export default function Rooms() {
  return (
    <div className="pt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-serif font-bold text-malaysian-green mb-4">Luxury Accommodations</h1>
          <p className="text-lg text-warm-gray max-w-2xl mx-auto">Choose from our four distinctive room categories, each designed with traditional Malaysian elegance and modern amenities</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8">
          {rooms.map((room, index) => (
            <Card key={index} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2" data-testid={`room-${room.title.toLowerCase().replace(/\s+/g, '-')}`}>
              <img src={room.image} alt={room.alt} className="w-full h-64 object-cover" />
              <CardContent className="p-6">
                <h2 className="text-2xl font-serif font-semibold text-malaysian-green mb-3">{room.title}</h2>
                <p className="text-warm-gray mb-4">{room.description}</p>
                <ul className="space-y-2 text-sm text-warm-gray mb-6">
                  {room.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <feature.icon className="text-malaysian-terracotta mr-2 h-4 w-4" />
                      {feature.text}
                    </li>
                  ))}
                </ul>
                <Button className="w-full bg-malaysian-terracotta text-white hover:bg-malaysian-burgundy transition-colors duration-200 font-semibold" data-testid={`view-details-${room.title.toLowerCase().replace(/\s+/g, '-')}`}>
                  View Details
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

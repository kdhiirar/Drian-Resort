import { Card, CardContent } from "@/components/ui/card";

const diningServices = [
  {
    title: "Breakfast",
    description: "Traditional Malaysian breakfast featuring nasi lemak, roti canai, and tropical fruits",
    icon: "fas fa-sun",
    color: "text-malaysian-gold",
  },
  {
    title: "Lunch",
    description: "Authentic Peranakan and Malay cuisine served in our heritage dining hall",
    icon: "fas fa-utensils",
    color: "text-malaysian-terracotta",
  },
  {
    title: "Dinner",
    description: "Fine dining experience with fusion of traditional and contemporary Malaysian flavors",
    icon: "fas fa-moon",
    color: "text-malaysian-burgundy",
  },
];

const facilities = [
  {
    title: "Swimming Pool & Spa",
    description: "Refresh in our pristine pool with integrated shower stalls and spa facilities",
    image: "https://images.unsplash.com/photo-1571896349842-33c89424de2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    alt: "Resort swimming pool with tropical landscaping",
  },
  {
    title: "Durian Garden & Stalls",
    description: "Experience Malaysia's king of fruits in our authentic durian garden and traditional stalls",
    image: "https://images.unsplash.com/photo-1583121274602-3e2820c69888?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    alt: "Durian garden with traditional Malaysian fruit trees",
  },
  {
    title: "Eco-Friendly Green House",
    description: "Sustainable luxury powered by solar energy, showcasing our commitment to environmental conservation",
    image: "https://images.unsplash.com/photo-1509391366360-2e959784a276?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    alt: "Solar panels on eco-friendly resort building",
  },
];

const additionalServices = [
  {
    title: "Room Service",
    description: "24/7 room service featuring authentic Malaysian cuisine and international favorites",
    icon: "fas fa-concierge-bell",
    color: "text-malaysian-terracotta",
  },
  {
    title: "Traditional Spa",
    description: "Rejuvenate with traditional Malay massage and herbal treatments in our heritage spa",
    icon: "fas fa-spa",
    color: "text-malaysian-gold",
  },
  {
    title: "Tropical Gardens",
    description: "Stroll through our lush tropical gardens featuring native Malaysian flora and fauna",
    icon: "fas fa-leaf",
    color: "text-malaysian-green",
  },
];

export default function Facilities() {
  return (
    <div className="pt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-serif font-bold text-malaysian-green mb-4">Resort Facilities</h1>
          <p className="text-lg text-warm-gray max-w-2xl mx-auto">Experience authentic Malaysian hospitality with our comprehensive range of traditional and modern amenities</p>
        </div>
        
        {/* Dining Services */}
        <div className="mb-16">
          <h2 className="text-3xl font-serif font-semibold text-malaysian-green mb-8 text-center">Culinary Experiences</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {diningServices.map((service, index) => (
              <Card key={index} className="bg-white rounded-xl shadow-lg p-6 text-center hover:shadow-xl transition-shadow duration-300" data-testid={`dining-${service.title.toLowerCase()}`}>
                <CardContent className="p-0">
                  <i className={`${service.icon} text-4xl ${service.color} mb-4`}></i>
                  <h3 className="text-xl font-semibold text-malaysian-green mb-3">{service.title}</h3>
                  <p className="text-warm-gray">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Recreation Facilities */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-8">
          {facilities.map((facility, index) => (
            <Card key={index} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300" data-testid={`facility-${facility.title.toLowerCase().replace(/\s+/g, '-')}`}>
              <img src={facility.image} alt={facility.alt} className="w-full h-48 object-cover" />
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-malaysian-green mb-3">{facility.title}</h3>
                <p className="text-warm-gray">{facility.description}</p>
              </CardContent>
            </Card>
          ))}

          {additionalServices.map((service, index) => (
            <Card key={index} className="bg-white rounded-xl shadow-lg p-6 text-center hover:shadow-xl transition-shadow duration-300" data-testid={`service-${service.title.toLowerCase().replace(/\s+/g, '-')}`}>
              <CardContent className="p-0">
                <i className={`${service.icon} text-4xl ${service.color} mb-4`}></i>
                <h3 className="text-xl font-semibold text-malaysian-green mb-3">{service.title}</h3>
                <p className="text-warm-gray">{service.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

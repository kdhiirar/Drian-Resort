import { Award } from "lucide-react";

export default function About() {
  const stats = [
    { value: "15+", label: "Years of Hospitality" },
    { value: "100%", label: "Solar Powered" },
    { value: "24/7", label: "Guest Services" },
    { value: "4.9★", label: "Guest Rating" },
  ];

  return (
    <div className="pt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-4xl font-serif font-bold text-malaysian-green mb-6">Our Heritage Story</h1>
            <p className="text-lg text-warm-gray mb-6 leading-relaxed">D'Rian Resort embodies the soul of Malaysia, where traditional architecture meets contemporary luxury. Nestled in the historic city of Malacca, our resort is housed in a beautifully preserved traditional Malaysian house that has been thoughtfully modernized to provide world-class amenities while maintaining its cultural authenticity.</p>
            
            <p className="text-lg text-warm-gray mb-6 leading-relaxed">Our commitment to sustainability is reflected in our eco-friendly green house design and solar panel energy system, making us a responsible choice for environmentally conscious travelers. Located near Malacca's pristine beaches, we offer the perfect blend of cultural immersion and natural beauty.</p>
            
            <div className="grid grid-cols-2 gap-6 mt-8">
              {stats.map((stat, index) => (
                <div key={index} className="text-center" data-testid={`stat-${stat.label.toLowerCase().replace(/\s+/g, '-')}`}>
                  <div className="text-3xl font-bold text-malaysian-terracotta">{stat.value}</div>
                  <div className="text-warm-gray">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Traditional Malaysian heritage building with cultural architecture" 
              className="rounded-xl shadow-lg w-full"
              data-testid="heritage-building-image"
            />
            <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-malaysian-gold rounded-full flex items-center justify-center shadow-lg">
              <Award className="text-white text-2xl" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

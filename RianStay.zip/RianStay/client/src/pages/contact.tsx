import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Phone, Mail, Clock, MapPin } from "lucide-react";

export default function Contact() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    checkIn: "",
    message: "",
  });

  const contactInfo = [
    {
      icon: Phone,
      title: "Phone",
      info: "+60 6-123 4567",
    },
    {
      icon: Mail,
      title: "Email",
      info: "reservations@drianresort.com",
    },
    {
      icon: Clock,
      title: "Operating Hours",
      info: "24/7 Front Desk & Concierge",
    },
    {
      icon: MapPin,
      title: "Address",
      info: "Jalan Pantai Klebang, 75200 Malacca, Malaysia",
    },
  ];

  const socialLinks = [
    { platform: "facebook", icon: "fab fa-facebook-f" },
    { platform: "instagram", icon: "fab fa-instagram" },
    { platform: "twitter", icon: "fab fa-twitter" },
    { platform: "youtube", icon: "fab fa-youtube" },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Message Sent!",
      description: "Thank you for your inquiry. We'll get back to you soon.",
    });
    setFormData({
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      checkIn: "",
      message: "",
    });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <div className="pt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-serif font-bold text-malaysian-green mb-4">Contact Us</h1>
          <p className="text-lg text-warm-gray max-w-2xl mx-auto">Ready to experience traditional Malaysian hospitality? Get in touch with our team for reservations and inquiries</p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12">
          <div>
            <h2 className="text-2xl font-serif font-semibold text-malaysian-green mb-6">Get in Touch</h2>
            <div className="space-y-6 mb-8">
              {contactInfo.map((contact, index) => (
                <div key={index} className="flex items-center" data-testid={`contact-${contact.title.toLowerCase().replace(/\s+/g, '-')}`}>
                  <div className="w-12 h-12 bg-malaysian-terracotta rounded-full flex items-center justify-center mr-4">
                    <contact.icon className="text-white h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-malaysian-green">{contact.title}</h3>
                    <p className="text-warm-gray">{contact.info}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex space-x-4">
              {socialLinks.map((social, index) => (
                <a 
                  key={index}
                  href="#" 
                  className="w-12 h-12 bg-malaysian-green rounded-full flex items-center justify-center text-white hover:bg-malaysian-terracotta transition-colors duration-200"
                  data-testid={`social-${social.platform}`}
                >
                  <i className={social.icon}></i>
                </a>
              ))}
            </div>
          </div>
          
          <Card className="bg-malaysian-cream rounded-xl p-8">
            <h2 className="text-2xl font-serif font-semibold text-malaysian-green mb-6">Send us a Message</h2>
            <form onSubmit={handleSubmit} className="space-y-6" data-testid="contact-form">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="firstName" className="block text-sm font-medium text-malaysian-green mb-2">First Name</Label>
                  <Input 
                    id="firstName"
                    name="firstName"
                    type="text" 
                    value={formData.firstName}
                    onChange={handleChange}
                    className="w-full focus:border-malaysian-terracotta focus:ring-malaysian-terracotta/20" 
                    data-testid="input-first-name"
                  />
                </div>
                <div>
                  <Label htmlFor="lastName" className="block text-sm font-medium text-malaysian-green mb-2">Last Name</Label>
                  <Input 
                    id="lastName"
                    name="lastName"
                    type="text" 
                    value={formData.lastName}
                    onChange={handleChange}
                    className="w-full focus:border-malaysian-terracotta focus:ring-malaysian-terracotta/20" 
                    data-testid="input-last-name"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="email" className="block text-sm font-medium text-malaysian-green mb-2">Email</Label>
                <Input 
                  id="email"
                  name="email"
                  type="email" 
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full focus:border-malaysian-terracotta focus:ring-malaysian-terracotta/20" 
                  data-testid="input-email"
                />
              </div>
              <div>
                <Label htmlFor="phone" className="block text-sm font-medium text-malaysian-green mb-2">Phone</Label>
                <Input 
                  id="phone"
                  name="phone"
                  type="tel" 
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full focus:border-malaysian-terracotta focus:ring-malaysian-terracotta/20" 
                  data-testid="input-phone"
                />
              </div>
              <div>
                <Label htmlFor="checkIn" className="block text-sm font-medium text-malaysian-green mb-2">Check-in Date</Label>
                <Input 
                  id="checkIn"
                  name="checkIn"
                  type="date" 
                  value={formData.checkIn}
                  onChange={handleChange}
                  className="w-full focus:border-malaysian-terracotta focus:ring-malaysian-terracotta/20" 
                  data-testid="input-check-in"
                />
              </div>
              <div>
                <Label htmlFor="message" className="block text-sm font-medium text-malaysian-green mb-2">Message</Label>
                <Textarea 
                  id="message"
                  name="message"
                  rows={4} 
                  value={formData.message}
                  onChange={handleChange}
                  className="w-full focus:border-malaysian-terracotta focus:ring-malaysian-terracotta/20" 
                  placeholder="Tell us about your stay preferences..."
                  data-testid="input-message"
                />
              </div>
              <Button 
                type="submit" 
                className="w-full bg-malaysian-terracotta text-white hover:bg-malaysian-burgundy transition-colors duration-200 font-semibold"
                data-testid="submit-message"
              >
                Send Message
              </Button>
            </form>
          </Card>
        </div>
      </div>
    </div>
  );
}
